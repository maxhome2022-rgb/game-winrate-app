"""OpenDota API로 Dota 2 플레이어 데이터를 모아 dota_players.csv로 저장합니다.

플레이어 한 명마다 아래 API를 모두 호출해서 숫자 요약값(컬럼)으로 바꿉니다.

  /players/{id}/wl            승·패 횟수            → wins, losses, win_rate
  /players/{id}/matches       경기 기록             → hours(총 플레이 시간), active_days
  /players/{id}               프로필                → rank_tier
  /players/{id}/rankings      영웅별 랭킹           → hero_ranked_count, hero_percent_rank_mean
  /players/{id}/ratings       레이팅 기록           → rating_count, rating_latest
  /players/{id}/wordcloud     채팅 단어             → chat_words
  /players/{id}/wardmap       와드 설치 위치        → obs_wards, sen_wards
  /players/{id}/histograms/kills  킬 분포           → kills_hist_mean
  /players/{id}/counts        게임 모드·이탈 등     → abandon_rate
  /players/{id}/totals        항목별 누적 통계      → avg_kills, avg_deaths, ...
  /players/{id}/pros          함께 뛴 프로 선수     → pro_peer_count
  /players/{id}/peers         함께 뛴 플레이어      → peer_count
  /players/{id}/heroes        영웅별 기록           → hero_pool, top_hero_share
  /players/{id}/recentMatches 최근 20경기           → recent_win_rate

플레이어 번호는 /publicMatches 와 /matches/{match_id} 에서 가져옵니다.

실행: python collect_data.py          (기본 150명)
      python collect_data.py 300      (300명)
- 플레이어 한 명에 API를 약 15번 호출해서 150명에 40분쯤 걸립니다.
- 중간에 멈춰도 저장된 데이터는 남고, 다시 실행하면 이어서 모읍니다.
"""
import csv
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

BASE = "https://api.opendota.com/api"
OUT_PATH = Path(__file__).parent / "dota_players.csv"

TARGET_PLAYERS = 150   # 모을 플레이어 수 (실행할 때 숫자로 바꿀 수 있음)
MIN_MATCHES = 20       # 경기 수가 이보다 적은 플레이어는 제외
WAIT = 1.1             # 요청 사이 대기 시간(초) - 무료 한도(분당 60회)를 지키기 위함
HISTOGRAM_FIELD = "kills"

TOTAL_FIELDS = {       # /totals 에서 평균을 낼 항목 → 컬럼 이름
    "kills": "avg_kills",
    "deaths": "avg_deaths",
    "assists": "avg_assists",
    "gold_per_min": "avg_gpm",
    "xp_per_min": "avg_xpm",
    "last_hits": "avg_last_hits",
    "hero_damage": "avg_hero_damage",
    "tower_damage": "avg_tower_damage",
}

FIELDS = [
    "account_id", "wins", "losses", "matches", "hours", "win_rate",
    "active_days", "rank_tier", "hero_ranked_count", "hero_percent_rank_mean",
    "rating_count", "rating_latest", "chat_words", "obs_wards", "sen_wards",
    "kills_hist_mean", "abandon_rate", *TOTAL_FIELDS.values(),
    "pro_peer_count", "peer_count", "hero_pool", "top_hero_share", "recent_win_rate",
]


# ---------------------------------------------------------------- API 호출
def get_json(path):
    """API를 호출해 JSON을 돌려줍니다. 실패하면 None."""
    req = urllib.request.Request(BASE + path, headers={"User-Agent": "game-winrate-app"})
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=60) as res:
                data = json.loads(res.read().decode("utf-8"))
            time.sleep(WAIT)
            return data
        except urllib.error.HTTPError as e:
            if e.code == 404:
                time.sleep(WAIT)
                return None
            if e.code == 429:  # 너무 자주 요청함
                print("  요청이 너무 많아 30초 쉽니다...")
                time.sleep(30)
            else:
                time.sleep(5)
        except Exception as e:  # 네트워크 오류 등
            print(f"  오류: {e} (다시 시도 {attempt + 1}/5)")
            time.sleep(5)
    return None


def new_account_ids(known):
    """공개 경기에서 아직 모르는 플레이어 번호를 하나씩 꺼내줍니다."""
    seen_matches = set()
    for _ in range(30):  # 최근 경기 목록을 최대 30번 새로 받아옴
        for m in get_json("/publicMatches") or []:
            match_id = m.get("match_id")
            if match_id in seen_matches:
                continue
            seen_matches.add(match_id)
            match = get_json(f"/matches/{match_id}")
            for p in (match or {}).get("players", []):
                account_id = p.get("account_id")  # 비공개 플레이어는 None
                if account_id and account_id not in known:
                    known.add(account_id)
                    yield account_id
        time.sleep(30)  # 새 경기가 올라올 때까지 잠깐 기다림


# ---------------------------------------------------------------- 요약 함수
# 각 함수는 API 응답을 받아 숫자 하나(또는 몇 개)로 줄입니다.
# 응답이 비었거나 모양이 달라도 오류 없이 None을 돌려줍니다.
def _as_list(data):
    return data if isinstance(data, list) else []


def _as_dict(data):
    return data if isinstance(data, dict) else {}


def _nested_sum(d):
    """{x: {y: 개수}} 모양의 값을 모두 더합니다."""
    total = 0
    for inner in _as_dict(d).values():
        if isinstance(inner, dict):
            total += sum(v for v in inner.values() if isinstance(v, (int, float)))
        elif isinstance(inner, (int, float)):
            total += inner
    return total


def summarize_profile(data):
    return {"rank_tier": _as_dict(data).get("rank_tier")}


def summarize_rankings(data):
    rows = _as_list(data)
    pct = [r["percent_rank"] * 100 for r in rows
           if isinstance(r, dict) and isinstance(r.get("percent_rank"), (int, float))]
    return {
        "hero_ranked_count": len(rows),
        "hero_percent_rank_mean": round(sum(pct) / len(pct), 2) if pct else None,
    }


def summarize_ratings(data):
    rows = [r for r in _as_list(data) if isinstance(r, dict)]
    latest = max(rows, key=lambda r: r.get("time") or 0) if rows else {}
    return {
        "rating_count": len(rows),
        "rating_latest": latest.get("solo_competitive_rank") or latest.get("competitive_rank"),
    }


def summarize_wordcloud(data):
    words = _as_dict(_as_dict(data).get("my_word_counts"))
    return {"chat_words": sum(v for v in words.values() if isinstance(v, (int, float)))}


def summarize_wardmap(data):
    d = _as_dict(data)
    return {"obs_wards": _nested_sum(d.get("obs")), "sen_wards": _nested_sum(d.get("sen"))}


def summarize_histogram(data):
    rows = [r for r in _as_list(data) if isinstance(r, dict)]
    games = sum(r.get("games") or 0 for r in rows)
    if not games:
        return {"kills_hist_mean": None}
    mean = sum((r.get("x") or 0) * (r.get("games") or 0) for r in rows) / games
    return {"kills_hist_mean": round(mean, 2)}


def summarize_counts(data):
    leaver = _as_dict(_as_dict(data).get("leaver_status"))
    total = sum((v or {}).get("games", 0) for v in leaver.values() if isinstance(v, dict))
    if not total:
        return {"abandon_rate": None}
    left = sum(v.get("games", 0) for k, v in leaver.items()
               if isinstance(v, dict) and str(k) != "0")
    return {"abandon_rate": round(left / total * 100, 2)}


def summarize_totals(data):
    out = {col: None for col in TOTAL_FIELDS.values()}
    for row in _as_list(data):
        if isinstance(row, dict) and row.get("field") in TOTAL_FIELDS and row.get("n"):
            out[TOTAL_FIELDS[row["field"]]] = round(row["sum"] / row["n"], 2)
    return out


def summarize_heroes(data):
    games = [r.get("games") or 0 for r in _as_list(data) if isinstance(r, dict)]
    played = [g for g in games if g > 0]
    return {
        "hero_pool": len(played),
        "top_hero_share": round(max(played) / sum(played) * 100, 2) if played else None,
    }


def summarize_matches(data):
    rows = [m for m in _as_list(data) if isinstance(m, dict)]
    seconds = sum(m.get("duration") or 0 for m in rows)
    starts = [m["start_time"] for m in rows if m.get("start_time")]
    days = round((max(starts) - min(starts)) / 86400) if starts else None
    return {"count": len(rows), "hours": round(seconds / 3600, 2), "active_days": days}


def summarize_recent(data):
    rows = [m for m in _as_list(data) if isinstance(m, dict)]
    wins = 0
    for m in rows:
        if "player_slot" in m and "radiant_win" in m:
            wins += (m["player_slot"] < 128) == bool(m["radiant_win"])
    return {"recent_win_rate": round(wins / len(rows) * 100, 2) if rows else None}


# ---------------------------------------------------------------- 플레이어 수집
def collect_player(i):
    """플레이어 한 명의 기록을 dict로 만듭니다. 쓸 수 없으면 None."""
    wl = _as_dict(get_json(f"/players/{i}/wl"))
    wins, losses = wl.get("win", 0), wl.get("lose", 0)
    total = wins + losses
    if total < MIN_MATCHES:  # 비공개이거나 경기가 적은 플레이어는 여기서 바로 제외
        return None

    matches = summarize_matches(get_json(f"/players/{i}/matches?project=duration&project=start_time"))
    # 받아온 경기 수가 승패 합계보다 많이 적으면 플레이 시간이 낮게 계산되므로 제외
    if matches["count"] < total * 0.9:
        return None

    row = {
        "account_id": i, "wins": wins, "losses": losses, "matches": total,
        "hours": matches["hours"], "active_days": matches["active_days"],
        "win_rate": round(wins / total * 100, 2),
    }
    row.update(summarize_profile(get_json(f"/players/{i}")))
    row.update(summarize_rankings(get_json(f"/players/{i}/rankings")))
    row.update(summarize_ratings(get_json(f"/players/{i}/ratings")))
    row.update(summarize_wordcloud(get_json(f"/players/{i}/wordcloud")))
    row.update(summarize_wardmap(get_json(f"/players/{i}/wardmap")))
    row.update(summarize_histogram(get_json(f"/players/{i}/histograms/{HISTOGRAM_FIELD}")))
    row.update(summarize_counts(get_json(f"/players/{i}/counts")))
    row.update(summarize_totals(get_json(f"/players/{i}/totals")))
    row["pro_peer_count"] = len(_as_list(get_json(f"/players/{i}/pros")))
    row["peer_count"] = len(_as_list(get_json(f"/players/{i}/peers")))
    row.update(summarize_heroes(get_json(f"/players/{i}/heroes")))
    row.update(summarize_recent(get_json(f"/players/{i}/recentMatches")))
    return row


def load_done():
    """이미 저장된 플레이어를 읽습니다. 예전 형식 파일이면 백업하고 새로 시작합니다."""
    if not OUT_PATH.exists():
        return []
    with open(OUT_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != FIELDS:
            backup = OUT_PATH.with_name("dota_players_old.csv")
            f.close()
            OUT_PATH.replace(backup)
            print(f"예전 형식의 파일을 {backup.name}로 옮기고 새로 시작합니다.")
            return []
        return list(reader)


def main():
    target = int(sys.argv[1]) if len(sys.argv) > 1 else TARGET_PLAYERS
    rows = load_done()
    known = {int(r["account_id"]) for r in rows}
    print(f"이미 저장된 플레이어: {len(rows)}명 / 목표: {target}명")

    is_new_file = not OUT_PATH.exists()
    with open(OUT_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        if is_new_file:
            writer.writeheader()

        count = len(rows)
        for account_id in new_account_ids(known):
            if count >= target:
                break
            row = collect_player(account_id)
            if row is None:
                continue
            writer.writerow(row)
            f.flush()  # 중간에 멈춰도 저장되도록 바로 기록
            count += 1
            print(f"[{count}/{target}] {account_id}: {row['hours']}시간, 승률 {row['win_rate']}%")

    print(f"완료! {OUT_PATH.name}에 {count}명이 저장되었습니다.")


if __name__ == "__main__":
    main()
