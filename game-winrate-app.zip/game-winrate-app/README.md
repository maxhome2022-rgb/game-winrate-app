# 🎮 게임 플레이 시간에 따른 승률 예측

게임(Call of Duty, Dota 2)을 고르고 플레이 시간을 슬라이더로 선택하면 예상 승률을 보여주는 데이터 분석 웹앱입니다.
Python과 Streamlit으로 만들었습니다.

## 주요 기능

- 게임 선택 (Call of Duty / Dota 2)
- 게임 플레이 시간 입력 슬라이더
- 예상 승률 출력 (숫자 + 진행 막대)
- 실제 데이터 산점도 (플레이 시간 vs 승률)
- 다른 지표(킬/데스 비율, 랭크 티어 등)와 승률의 상관관계 표와 그래프
- 두 게임 비교 표

## 사용한 데이터

### 1. Call of Duty (`cod.csv`)

- [Call of Duty Players Skills (Kaggle)](https://www.kaggle.com/datasets/aishahakami/call-of-duty-players)
- 승률 = `wins / (wins + losses) × 100`, 플레이 시간 = `timePlayed`
- 경기 수가 20회 이상인 플레이어만 사용
- 승률 중앙값이 약 94%로 매우 높고, 플레이 시간 단위도 확실하지 않아 해석에 주의가 필요합니다.

### 2. Dota 2 (`dota_players.csv`)

[OpenDota API](https://docs.opendota.com)로 플레이어 데이터를 직접 수집했습니다. (`collect_data.py` → `dota_players.csv`)

| 사용한 API | 만들어지는 컬럼 |
|---|---|
| `/publicMatches`, `/matches/{match_id}` | 플레이어 번호(account_id) 수집 |
| `/players/{account_id}/wl` | wins, losses, win_rate |
| `/players/{account_id}/matches` | hours(총 플레이 시간), active_days |
| `/players/{account_id}` | rank_tier |
| `/players/{account_id}/rankings` | hero_ranked_count, hero_percent_rank_mean |
| `/players/{account_id}/ratings` | rating_count, rating_latest |
| `/players/{account_id}/wordcloud` | chat_words |
| `/players/{account_id}/wardmap` | obs_wards, sen_wards |
| `/players/{account_id}/histograms/kills` | kills_hist_mean |
| `/players/{account_id}/counts` | abandon_rate |
| `/players/{account_id}/totals` | avg_kills, avg_deaths, avg_assists, avg_gpm, avg_xpm, avg_last_hits, avg_hero_damage, avg_tower_damage |
| `/players/{account_id}/pros` | pro_peer_count |
| `/players/{account_id}/peers` | peer_count |
| `/players/{account_id}/heroes` | hero_pool, top_hero_share |
| `/players/{account_id}/recentMatches` | recent_win_rate |

- 승률 = `wins / (wins + losses) × 100`
- 플레이 시간 = 모든 경기 시간의 합계 (시간 단위, 대기·로비 시간은 제외)
- 경기 수가 20회 이상인 플레이어만 사용

## 예측 방식

승률은 플레이 시간이 늘수록 점점 완만하게 변하기 때문에,
플레이 시간에 로그(`log1p`)를 취한 뒤 직선 회귀(`numpy.polyfit`)로 학습합니다.

## Dota 2 데이터 수집 방법

```bash
python collect_data.py
```

- 플레이어 한 명마다 API를 약 15번 호출해서, 150명을 모으는 데 40분쯤 걸립니다. (무료 API 한도를 지키려고 요청마다 쉬어요)
- 모을 인원은 `python collect_data.py 300`처럼 숫자로 바꿀 수 있습니다.
- 중간에 멈춰도 저장된 데이터는 남고, 다시 실행하면 이어서 모읍니다.
- 결과는 `dota_players.csv`로 저장됩니다.

## 앱 실행 방법

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 배포 (Streamlit Community Cloud)

1. 이 저장소를 GitHub에 올립니다. (`cod.csv`, `dota_players.csv`가 `app.py`와 같은 위치에 있어야 합니다. 한쪽 파일이 없으면 그 게임을 고를 때 안내 문구가 나옵니다.)
2. [share.streamlit.io](https://share.streamlit.io)에서 GitHub 계정으로 로그인합니다.
3. 저장소를 선택하고 Main file path를 `app.py`로 지정한 뒤 Deploy 합니다.

## 바이브 코딩 프롬프트

> 게임 플레이 시간에 따른 승률을 예측하는 데이터 분석 웹앱을 만들고 싶어. Python과 Streamlit을 활용하여 웹앱의 기본 화면을 만들어줘. 제목은 '게임 플레이 시간에 따른 승률 예측'으로 설정하고, 게임 플레이 시간을 입력할 수 있는 슬라이더와 예상 승률을 출력하는 영역을 만들어줘.

## 참고 및 한계

- 두 게임은 데이터를 모은 방식과 시간 단위가 달라서, 숫자를 직접 비교하기보다 경향을 참고해야 합니다.
- Dota 2 데이터는 최근 공개 경기에 참여한 플레이어를 모은 표본이라서, 전체 플레이어를 대표하지 않습니다.
- 플레이 시간은 경기 시간만 합친 값이라 실제 접속 시간과 다릅니다.
- 경기 기록을 비공개로 설정한 플레이어는 포함되지 않습니다.
- `avg_kills`나 `recent_win_rate`처럼 이긴 결과가 반영된 지표는 승률의 원인이 아니라 결과일 수 있습니다.
- 이 앱의 예측은 데이터에서 나타난 경향일 뿐, 개인의 실제 승률을 보장하지 않습니다.
