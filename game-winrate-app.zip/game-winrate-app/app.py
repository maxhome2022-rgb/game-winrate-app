import re
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="게임 플레이 시간에 따른 승률 예측", page_icon="🎮")

BASE_DIR = Path(__file__).parent
TIME_UNIT = "시간"
MIN_MATCHES = 20  # 경기 수가 너무 적은 플레이어는 승률이 불안정해서 제외


def find_csv(stem):
    """폴더에서 데이터 파일을 찾습니다.
    cod.csv 말고도 'cod .csv', 'cod (1).csv'처럼 이름이 조금 달라도 찾아줍니다."""
    pattern = re.compile(rf"{re.escape(stem)}(\(\d+\))?\.csv")
    for path in sorted(BASE_DIR.glob("*.csv")):
        if pattern.fullmatch(path.name.lower().replace(" ", "")):
            return path
    return None


# ---------------------------------------------------------------- 데이터 읽기
# 두 게임의 데이터는 컬럼이 달라서, 읽으면서 같은 이름(hours, matches, win_rate)으로 맞춥니다.
@st.cache_data
def load_cod(path):
    df = pd.read_csv(path)
    df["matches"] = df["wins"] + df["losses"]
    df["hours"] = df["timePlayed"]
    df = df[(df["matches"] >= MIN_MATCHES) & (df["hours"] > 0)].copy()
    df["win_rate"] = df["wins"] / df["matches"] * 100
    df["headshot_rate"] = (df["headshots"] / df["kills"] * 100).replace([np.inf, -np.inf], np.nan)
    df["accuracy"] = (df["hits"] / df["shots"] * 100).replace([np.inf, -np.inf], np.nan)
    return df


@st.cache_data
def load_dota(path):
    df = pd.read_csv(path)
    return df[(df["matches"] >= MIN_MATCHES) & (df["hours"] > 0)].copy()


# 승률과의 관계를 살펴볼 추가 지표 (CSV 컬럼 이름 → 화면에 보일 이름)
COD_FEATURES = {
    "matches": "총 경기 수",
    "kdRatio": "킬/데스 비율",
    "kills": "총 킬 수",
    "deaths": "총 데스 수",
    "assists": "총 어시스트",
    "killstreak": "최고 연속 킬",
    "level": "레벨",
    "prestige": "프레스티지",
    "xp": "경험치",
    "scorePerMinute": "분당 점수",
    "averageTime": "평균 경기 시간",
    "headshot_rate": "헤드샷 비율(%)",
    "accuracy": "명중률(%)",
}

DOTA_FEATURES = {
    "matches": "총 경기 수",
    "active_days": "활동 기간(일)",
    "rank_tier": "랭크 티어(숫자)",
    "hero_ranked_count": "랭킹이 있는 영웅 수",
    "hero_percent_rank_mean": "영웅 랭킹 평균 상위 %",
    "rating_count": "레이팅 기록 수",
    "rating_latest": "최근 레이팅",
    "chat_words": "채팅 단어 수",
    "obs_wards": "관측 와드 수",
    "sen_wards": "감시 와드 수",
    "kills_hist_mean": "경기당 평균 킬(분포)",
    "abandon_rate": "이탈 경기 비율(%)",
    "avg_kills": "평균 킬",
    "avg_deaths": "평균 데스",
    "avg_assists": "평균 어시스트",
    "avg_gpm": "분당 골드(GPM)",
    "avg_xpm": "분당 경험치(XPM)",
    "avg_last_hits": "평균 막타",
    "avg_hero_damage": "평균 영웅 피해량",
    "avg_tower_damage": "평균 타워 피해량",
    "pro_peer_count": "함께 뛴 프로 선수 수",
    "peer_count": "함께 뛴 플레이어 수",
    "hero_pool": "플레이한 영웅 수",
    "top_hero_share": "최다 영웅 비중(%)",
    "recent_win_rate": "최근 20경기 승률(%)",
}

GAMES = {
    "Call of Duty": {
        "stem": "cod",
        "loader": load_cod,
        "features": COD_FEATURES,
        "missing": "cod.csv 파일을 찾을 수 없습니다. app.py와 같은 위치(저장소 맨 위)에 올려주세요.",
        "notes": [
            "이 데이터의 승률은 중앙값이 약 94%로 매우 높아서, 일반적인 매치 승률과는 다를 수 있습니다.",
            "플레이 시간은 Kaggle 설명에는 '시간'으로 적혀 있지만, 값의 크기를 볼 때 단위가 확실하지 않습니다.",
        ],
    },
    "Dota 2": {
        "stem": "dota_players",
        "loader": load_dota,
        "features": DOTA_FEATURES,
        "missing": "dota_players.csv 파일을 찾을 수 없습니다. collect_data.py를 실행해 만든 뒤 "
                   "app.py와 같은 위치(저장소 맨 위)에 올려주세요.",
        "notes": [
            "최근 공개 경기에 참여한 플레이어를 모은 표본이라서, 전체 플레이어를 대표하지 않습니다.",
            "플레이 시간은 경기 시간만 합친 값이라 실제 접속 시간과 다릅니다.",
        ],
    },
}


# ---------------------------------------------------------------- 모델
@st.cache_data
def fit_model(df):
    # 플레이 시간에 log를 취해 직선(1차식)으로 학습합니다.
    x = np.log1p(df["hours"])
    y = df["win_rate"]
    slope, intercept = np.polyfit(x, y, 1)
    r2 = np.corrcoef(x, y)[0, 1] ** 2
    return slope, intercept, r2


def predict_win_rate(hours, slope, intercept):
    return float(np.clip(slope * np.log1p(hours) + intercept, 0, 100))


# ---------------------------------------------------------------- 화면
st.title("게임 플레이 시간에 따른 승률 예측")
st.write("게임을 고르고 플레이 시간을 선택하면, 그 게임의 데이터로 예상 승률을 보여줍니다.")

game = st.radio("게임 선택", list(GAMES), horizontal=True)
cfg = GAMES[game]

path = find_csv(cfg["stem"])
if path is None:
    st.error(cfg["missing"])
    st.stop()

df = cfg["loader"](path)
slope, intercept, r2 = fit_model(df)

st.divider()

st.subheader("플레이 시간 입력")
min_time = max(1, int(df["hours"].min()))
max_time = int(df["hours"].quantile(0.99))
play_time = st.slider(
    f"{game} 플레이 시간 ({TIME_UNIT})",
    min_value=min_time,
    max_value=max_time,
    value=int(df["hours"].median()),
    key=f"slider_{game}",
)

win_rate = predict_win_rate(play_time, slope, intercept)

st.divider()

st.subheader("예상 승률")
col1, col2 = st.columns(2)
col1.metric("선택한 플레이 시간", f"{play_time:,} {TIME_UNIT}")
col2.metric("예상 승률", f"{win_rate:.1f} %")
st.progress(int(win_rate))

st.divider()

st.subheader("데이터 보기")
chart_df = df[["hours", "win_rate"]].rename(
    columns={"hours": f"플레이 시간({TIME_UNIT})", "win_rate": "승률(%)"}
)
st.scatter_chart(chart_df, x=f"플레이 시간({TIME_UNIT})", y="승률(%)")
st.caption(
    f"분석 대상: 경기 수 {MIN_MATCHES}회 이상인 플레이어 {len(df):,}명 · "
    f"모델 설명력(R²) {r2:.2f}"
)
for note in cfg["notes"]:
    st.caption(f"※ {note}")

# ---- 다른 지표와 승률의 관계 ----
labels = cfg["features"]
features = [c for c in labels if c in df.columns and df[c].nunique() > 1]
if features:
    st.divider()
    st.subheader("다른 지표와 승률의 관계")
    corr = df[features + ["win_rate"]].corr()["win_rate"].drop("win_rate").dropna()
    corr_table = (
        corr.sort_values(key=lambda s: s.abs(), ascending=False)
        .rename(index=labels)
        .rename("승률과의 상관계수")
        .round(2)
        .to_frame()
    )
    st.write("상관계수가 1 또는 -1에 가까울수록 승률과 함께 움직이는 정도가 커요.")
    st.dataframe(corr_table)

    choice = st.selectbox("그래프로 볼 지표", list(corr_table.index), key=f"feature_{game}")
    col_name = next(k for k, v in labels.items() if v == choice)
    st.scatter_chart(
        df[[col_name, "win_rate"]].dropna().rename(columns={col_name: choice, "win_rate": "승률(%)"}),
        x=choice,
        y="승률(%)",
    )
    st.caption("※ 킬 수나 최근 승률처럼 '이긴 결과'가 반영된 지표는 승률의 원인이 아니라 결과일 수 있습니다.")

# ---- 두 게임 비교 ----
rows = []
for name, g in GAMES.items():
    p = find_csv(g["stem"])
    if p is None:
        continue
    d = g["loader"](p)
    _, _, r = fit_model(d)
    rows.append({
        "게임": name,
        "플레이어 수": len(d),
        f"플레이 시간 중앙값({TIME_UNIT})": round(d["hours"].median(), 1),
        "승률 중앙값(%)": round(d["win_rate"].median(), 1),
        "R²": round(r, 2),
    })
if len(rows) > 1:
    st.divider()
    st.subheader("두 게임 비교")
    st.dataframe(pd.DataFrame(rows).set_index("게임"))
    st.caption("※ 게임마다 데이터를 모은 방식이 달라서, 숫자를 직접 비교하기보다 경향을 참고하세요.")

st.caption("※ 이 데이터에서 나타난 경향을 바탕으로 한 단순 예측이며, 실제 승률과 다를 수 있습니다.")
